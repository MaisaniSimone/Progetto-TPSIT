function start(event){
  event.dataTransfer.setData("pezzo", event.target.id);
}
function entra(event){
  event.preventDefault();
}
function fine1(event){
  event.preventDefault();
  var data = event.dataTransfer.getData("pezzo");
  var immagine= document.getElementById(data);
  var ubicazione1=document.getElementById("spazio1");
  var miaimmagine=document.createElement("img");
  miaimmagine.src=immagine.src;
  miaimmagine.draggable=false;
  miaimmagine.className=immagine.className;
  ubicazione1.removeChild(ubicazione1.firstChild);
  ubicazione1.appendChild(miaimmagine);
}
function fine2(event){
  event.preventDefault();
  var data = event.dataTransfer.getData("pezzo");
  var immagine= document.getElementById(data);
  var ubicazione1=document.getElementById("spazio2");
  var miaimmagine=document.createElement("img");
  miaimmagine.src=immagine.src;
  miaimmagine.draggable=false;
  miaimmagine.className=immagine.className;
  ubicazione1.removeChild(ubicazione1.firstChild);
  ubicazione1.appendChild(miaimmagine);
}
function fine3(event){
  event.preventDefault();
  var data = event.dataTransfer.getData("pezzo");
  var immagine= document.getElementById(data);
  var ubicazione1=document.getElementById("spazio3");
  var miaimmagine=document.createElement("img");
  miaimmagine.src=immagine.src;
  miaimmagine.draggable=false;
  miaimmagine.className=immagine.className;
  ubicazione1.removeChild(ubicazione1.firstChild);
  ubicazione1.appendChild(miaimmagine);
}
function fine4(event){
  event.preventDefault();
  var data = event.dataTransfer.getData("pezzo");
  var immagine= document.getElementById(data);
  var ubicazione1=document.getElementById("spazio4");
  var miaimmagine=document.createElement("img");
  miaimmagine.src=immagine.src;
  miaimmagine.draggable=false;
  miaimmagine.className=immagine.className;
  ubicazione1.removeChild(ubicazione1.firstChild);
  ubicazione1.appendChild(miaimmagine);
}
function fine5(event){
  event.preventDefault();
  var data = event.dataTransfer.getData("pezzo");
  var immagine= document.getElementById(data);
  var miaimmagine=document.createElement("img");
  miaimmagine.src=immagine.src;
  miaimmagine.draggable=false;
  miaimmagine.className=immagine.className;
  var ubicazione1=document.getElementById("spazio5");
  ubicazione1.removeChild(ubicazione1.firstChild);
  ubicazione1.appendChild(miaimmagine);
}
function verifica(){
  var miocod=document.getElementById("codice");
  if (miocod.value=="24531") {
    alert("Bravo è corretto");
      var bottone=document.createElement("input");
      bottone.type="button";
      bottone.value="invia";
      var fun=document.createAttribute("onclick");
      fun.value="invia()";
      bottone.setAttributeNode(fun);
      var info=document.createElement("input");
      info.type="text";
      info.id="vittoria";
      info.placeholder="Inserisci il tuo nickname"
      var bottom=document.getElementById('bottone');
      var messaggio=document.getElementById('testo');
      bottom.removeChild(bottom.firstChild);
      messaggio.removeChild(messaggio.firstChild);
      bottom.replaceChild(bottone,bottom.firstChild);
      messaggio.replaceChild(info,messaggio.firstChild);
      var finito=document.getElementById("puzzle");
      var miocorpo=document.getElementById("corpo");
      miocorpo.removeChild(finito);
      var compl=document.createElement("p");
      compl.innerHTML="COMPLIMENTI HAI RISOLTO QUESTO PUZZLE!!!"
      var bravo=document.getElementById("Complimenti");
      bravo.appendChild(compl);
    }else{
    alert("Sbagliato riprova")
  }
}
function invia(){
  var soprannome=document.getElementById('vittoria');
  localStorage.setItem('nick', soprannome.value);
  geolocalizza();
  classifica();
}
function classifica(){
  var nome=document.createElement("p");
  nome.innerHTML=localStorage.getItem("nick") + ", le cui cordinate sono: latitudine " + localStorage.getItem("lat") + " longitudine " + localStorage.getItem("lon") + " Altezza " + localStorage.getItem("alt");
  var classi=document.getElementById('classifica');
  classi.replaceChild(nome,classi.firstChild);
}
function geolocalizza(){
  if(navigator.geolocation){

   navigator.geolocation.getCurrentPosition(localizza,errore);
  }  else {
  alert("Mi dispiace, il suo dispositivo non supporta la geolocalizzazione.");
  }
}
function errore(errore) {
  switch(errore.code) {
  case errore.UNKNOWN_ERROR:
  alert("La geolocalizzazione non riesce a collegarsi.");
  break;
  case errore.PERMISSION_DENIED:
  alert("Non hai autorizzato la geolocalizzazione.");
  break;
  case errore.POSITION_UNAVAILABLE:
  alert("Non riusciamo a localizzarti.");
  break;
  case errore.TIMEOUT:
  alert("La geolocalizzazione ha superato il tempo limite.");
  break;
  }
}
function localizza(position) {
  var latitudine = position.coords.latitude;
  var longitudine = position.coords.longitude;
  var altezza=position.coords.altitude;
  localStorage.setItem("lat",latitudine);
  localStorage.setItem("lon",longitudine);
  localStorage.setItem("alt",altezza);
}
